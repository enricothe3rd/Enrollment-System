<!DOCTYPE html>
<html>
<head>
    <title>Welcome</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Welcome</h2>
        <p>Please choose an option:</p>
        
        <div class="action-buttons">
            <a href="login.php" class="btn">Login</a>
            <a href="register.php" class="btn">Register</a>
            <a href="forgot_password.php" class="btn">Forgot Password</a>
        </div>
    </div>
</body>
</html>
